import boto3

# S3 Connection
s3 = boto3.client('s3')
