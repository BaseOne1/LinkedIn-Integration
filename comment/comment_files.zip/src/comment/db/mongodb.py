from src.comment.components import get_mongo_collection
from datetime import datetime
from src.comment.utils.logger import get_logger

logger = get_logger("mongodb")

def insert_comment(comment_id, comment_text, post_id, activity_id):
    collection = get_mongo_collection()
    existing = collection.find_one({"comment_id": comment_id})
    if existing:
        logger.info(f"Comment already exists: {comment_id}")
        return
    doc = {
        "comment_id": comment_id,
        "comment_text": comment_text,
        "post_id": post_id,
        "activity_id": activity_id,
        "timestamp": datetime.utcnow()
    }
    collection.insert_one(doc)
    logger.info(f"Inserted comment: {comment_id}")
