import os
from dotenv import load_dotenv
from src.comment.llm.response_generator import generate_llm_response
from src.comment.comment_feature.replier import post_reply_to_linkedin
from src.comment.components import get_mongo_collection
from src.comment.utils.logger import get_logger

logger = get_logger("payloader")

load_dotenv()
collection = get_mongo_collection()

def process_comment_payload(post_id, post_text):
    comment = collection.find_one(
        {
            "post_id": post_id,
            "$or": [
                {"llm_response": {"$exists": False}},
                {"llm_response": None},
                {"llm_response": ""}
            ]
        },
        sort=[("timestamp", -1)]
    )

    if not comment:
        logger.info(f"No unprocessed comments for post ID: {post_id}")
        return

    comment_id = comment["comment_id"]
    comment_text = comment["comment_text"]
    activity_id = comment["activity_id"]

    logger.info(f"Generating LLM reply for comment ID: {comment_id}")
    llm_reply = generate_llm_response(comment_text, post_text)

    if not llm_reply:
        logger.warning("LLM failed to generate a response.")
        return
    success = post_reply_to_linkedin(activity_id, comment_id, llm_reply)

    if success:
        collection.update_one(
            {"_id": comment["_id"]},
            {
                "$set": {
                    "llm_response": llm_reply,
                    "replied_to_linkedin": True
                }
            }
        )
        logger.info(f"Posted and updated DB for comment: {comment_id}")
    else:
        logger.warning(f"Failed to post reply for comment ID: {comment_id}")
