from pymongo import MongoClient
from src.comment.config.config import settings
import os

def get_mongo_collection():
    client = MongoClient(settings.MONGO_URI)
    db = client[os.getenv("MONGO_DB_NAME")]
    return db[os.getenv("MONGO_COLLECTION_NAME")]
