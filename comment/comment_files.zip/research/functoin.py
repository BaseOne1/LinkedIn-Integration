import json
import ;;;;kokokkkkkkkkkkboto3
import os
import requests
from base64 import b64decode

# Load env vars from Lambda environment variables
ACCESS_TOKEN = os.getenv("ACCESS_TOKEN")
ORG_ID = os.getenv("ORG_ID_TARGET")
ORG_URN = f"urn:li:organization:{ORG_ID}"

s3 = boto3.client("s3")
bucket_name = "falaipostings"

def lambda_handler(event, context):
    print("Event received:", json.dumps(event))

    params = event.get("queryStringParameters", {})
    file_key = params.get("file")
    action = params.get("action")

    if not file_key or not action:
        return respond(400, "Missing required parameters.")

    print(f"File: {file_key}, Action: {action}")
    try:
        params = event.get('queryStringParameters', {})
        key = params.get('file')
        action = params.get('action')

        if not key or not action:
            return respond(400, "Missing 'file' or 'action' parameter.")

        print(f"🔔 Received action: {action} for file: {key}")

        if action == "approve":
            return handle_approval(key)
        elif action == "reject":
            return handle_rejection(key)
        else:
            return respond(400, "Invalid action. Use 'approve' or 'reject'.")
    except Exception as e:
        return respond(500, f"Error: {str(e)}")

def handle_approval(key):
    obj = s3.get_object(Bucket=bucket_name, Key=key)
    post_data = json.loads(obj['Body'].read())

    post_text = post_data["text"]
    image_base64 = post_data["image_base64"]
    image_bytes = b64decode(image_base64.split(",")[1])

    image_urn = upload_image_to_linkedin(image_bytes)
    if not image_urn:
        return respond(500, "❌ Failed to upload image to LinkedIn.")

    success = publish_post_to_linkedin(post_text, image_urn)
    if success:
        return respond(200, "✅ Successfully posted to LinkedIn!")
    else:
        return respond(500, "❌ Failed to post to LinkedIn.")

def handle_rejection(key):
    rejected_key = key.replace("pending/", "rejected/")
    s3.copy_object(Bucket=bucket_name, CopySource={'Bucket': bucket_name, 'Key': key}, Key=rejected_key)
    s3.delete_object(Bucket=bucket_name, Key=key)
    return respond(200, f"🗑️ Post rejected and moved to '{rejected_key}'.")

def upload_image_to_linkedin(image_bytes):
    upload_url = "https://api.linkedin.com/rest/images?action=initializeUpload"

    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json",
        "X-Restli-Protocol-Version": "2.0.0"
    }

    payload = {
        "initializeUploadRequest": {
            "owner": ORG_URN
        }
    }

    init_res = requests.post(upload_url, headers=headers, json=payload)
    if init_res.status_code != 200:
        print(f"❌ Init upload failed: {init_res.text}")
        return None

    upload_data = init_res.json()
    upload_url_actual = upload_data['value']['uploadUrl']
    asset_urn = upload_data['value']['image']

    put_res = requests.put(upload_url_actual, data=image_bytes, headers={'Authorization': f"Bearer {ACCESS_TOKEN}"})
    if put_res.status_code != 201:
        print(f"❌ Upload failed: {put_res.text}")
        return None

    return asset_urn

def publish_post_to_linkedin(text, image_urn):
    url = "https://api.linkedin.com/rest/posts"

    headers = {
        "Authorization": f"Bearer {ACCESS_TOKEN}",
        "Content-Type": "application/json",
        "X-Restli-Protocol-Version": "2.0.0"
    }

    payload = {
        "author": ORG_URN,
        "commentary": text,
        "visibility": "PUBLIC",
        "distribution": {
            "feedDistribution": "MAIN_FEED"
        },
        "lifecycleState": "PUBLISHED",
        "content": {
            "media": {
                "id": image_urn
            }
        }
    }

    # response = requests.post(url, headers=headers, json=payload)
    print("LinkedIn post response:", response.text)

    return response.status_code == 201

def respond(status_code, message):
    return {
        "statusCode": status_code,
        "body": json.dumps({"message": message}),
        "headers": {
            "Content-Type": "application/json"
        }
    }
